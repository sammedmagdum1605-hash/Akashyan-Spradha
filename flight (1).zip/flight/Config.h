#pragma once
#include <Arduino.h>

// =============================================================================
// ROCKET IDENTITY — SET THIS BEFORE FLASHING EACH TEAM'S ROCKET
// =============================================================================
// Organizer-assigned 8-bit ID (1–254). 0x00 and 0xFF are reserved.
// Each rocket in the competition MUST have a unique ID.
// This is the ONLY value that differs between per-team firmware builds.
//
// Example:
//   Team 1  → ROCKET_ID 1
//   Team 2  → ROCKET_ID 2
//   ...
//   Team 60 → ROCKET_ID 60
// =============================================================================
#define ROCKET_ID  12

// =============================================================================
// GPIO Pin Map  (FROZEN — matches Standard_Altitude_Telemetry_System ref v1.0)
// =============================================================================
// BMP280 (I2C)
#define PIN_BMP_SDA    21
#define PIN_BMP_SCL    22

// RA-02 / SX1278 LoRa (SPI)
#define PIN_LORA_MOSI  23
#define PIN_LORA_MISO  19
#define PIN_LORA_SCK   18
#define PIN_LORA_NSS    5
#define PIN_LORA_RST   14
#define PIN_LORA_DIO0  26

// LEDs
#define PIN_LED_SENS   27   // Sensor activity (blinks every BMP280 read)
#define PIN_LED_TX     25   // Transmit activity (pulses on every LoRa TX)
#define PIN_LED_STATUS 33   // System state / fault indicator

// Buzzer (ground station only — not populated on flight computer PCB)
#define PIN_BUZZER      4

// =============================================================================
// LoRa RF Configuration  (FROZEN — 434.500 MHz, SF7, BW125, CR4/5)
// =============================================================================
#define LORA_FREQ          434.5E6   // 434.500 MHz
#define LORA_BANDWIDTH     125000    // 125 kHz
#define LORA_SPREADFACTOR  7         // SF7
#define LORA_CODINGRATE    5         // 4/5
#define LORA_PREAMBLE      8         // 8 symbols
#define LORA_SYNC_WORD     0x12      // Private LoRa network sync word
#define LORA_TX_POWER      17        // dBm — pending final RF regulatory sign-off

// =============================================================================
// Telemetry Timing  (FROZEN — 2 Hz normal, burst at apogee)
// =============================================================================
#define TELEMETRY_INTERVAL_MS    66   // Normal telemetry: 15 Hz (approx 66ms)
#define APOGEE_BURST_COUNT       10   // Number of apogee packets to transmit
#define APOGEE_BURST_INTERVAL   200   // ms between apogee burst packets

// =============================================================================
// Altitude & Flight Detection Thresholds  (BASELINE — requires flight validation)
// =============================================================================
#define LAUNCH_ALT_THRESHOLD    10.0f   // metres above pad: launch declared
#define APOGEE_FALL_THRESHOLD    3.0f   // metres below peak: apogee candidate
#define APOGEE_PERSISTENCE          5   // consecutive falling samples to lock apogee

// =============================================================================
// Sensor Filter  (BASELINE)
// =============================================================================
// EMA smoothing factor: higher = more responsive, lower = smoother
// 0.3 gives ~300 ms time constant at 100 ms sensor period
#define FILTER_EMA_ALPHA        0.3f

// =============================================================================
// Cloud / MQTT Uplink  (ground station only)
// Fill in your uplink hotspot and broker details below.
// Leave UPLINK_SSID empty ("") to disable the uplink feature.
// =============================================================================
#define UPLINK_SSID      ""           // Hotspot SSID for cloud uplink
#define UPLINK_PASSWORD  ""           // Hotspot password
#define MQTT_BROKER      "mqtt.example.com"
#define MQTT_PORT        1883
#define MQTT_TOPIC       "rocket/telemetry"
