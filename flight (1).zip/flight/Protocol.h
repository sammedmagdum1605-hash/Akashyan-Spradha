#pragma once
#include <Arduino.h>

// =============================================================================
// Telemetry Packet Types
// =============================================================================
#define PKT_TYPE_NORMAL_ALTITUDE  0x01
#define PKT_TYPE_APOGEE           0x02

// =============================================================================
// Flight State Machine
// =============================================================================
enum FlightState : uint8_t {
    STATE_BOOT          = 0,
    STATE_READY         = 1,
    STATE_ASCENT        = 2,
    STATE_APOGEE_LOCKED = 3,
    STATE_DESCENT       = 4,
    STATE_LANDED        = 5,
};

// =============================================================================
// Over-the-air Telemetry Packet — exactly 6 bytes, big-endian 16-bit fields
// =============================================================================
#pragma pack(push, 1)
struct TelemetryPacket {
    uint8_t  rocket_id;   // Byte 0: organizer-assigned Rocket ID
    uint8_t  type;        // Byte 1: PKT_TYPE_NORMAL_ALTITUDE or PKT_TYPE_APOGEE
    uint16_t sequence;    // Bytes 2-3: packet sequence counter (big-endian)
    uint16_t altitude;    // Bytes 4-5: altitude in 0.1-m units (big-endian)
                          //            encoded = round(altitude_m * 10)
};
#pragma pack(pop)

static_assert(sizeof(TelemetryPacket) == 6, "TelemetryPacket must be exactly 6 bytes");
